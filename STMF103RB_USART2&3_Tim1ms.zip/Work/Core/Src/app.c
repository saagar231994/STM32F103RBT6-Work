#include"app.h"
#include"main.h"

/* USART2 RX context */
uint8_t usart2_rx_byte;
char    usart2_rx_buffer[RX_BUFFER_SIZE];
uint8_t usart2_rx_index = 0;

/* USART3 RX context */
uint8_t usart3_rx_byte;
char    usart3_rx_buffer[RX_BUFFER_SIZE];
uint8_t usart3_rx_index = 0;
uint8_t ch = 'A';
const char msg[] = "Hello from STM32 USART2\r\n";
const char msg1[] = "Hello from STM32 USART3\r\n";
volatile uint8_t B1_Button_Flag = 0;



uint8_t  rx_byte;                        // single byte buffer
char     rx_buffer[RX_BUFFER_SIZE];      // command buffer
uint8_t  rx_index = 0;

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  if (htim->Instance == TIM2)
  {
	  app1mstask();
  }
}


void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    /* ================= USART2 ================= */
    if (huart->Instance == USART2)
    {
        uint8_t rx = usart2_rx_byte;

        if (usart2_rx_index < RX_BUFFER_SIZE - 1)
        {
            usart2_rx_buffer[usart2_rx_index++] = rx;
            usart2_rx_buffer[usart2_rx_index] = '\0';
        }

        if (strcmp(usart2_rx_buffer, "sagar") == 0)
        {
            char ok[] = "User know\r\n";
            HAL_UART_Transmit(&huart2, (uint8_t*)ok, sizeof(ok) - 1, HAL_MAX_DELAY);
            usart2_rx_index = 0;
        }
        else if (usart2_rx_index >= strlen("sagar"))
        {
            char nok[] = "Un know\r\n";
            HAL_UART_Transmit(&huart2, (uint8_t*)nok, sizeof(nok) - 1, HAL_MAX_DELAY);
            usart2_rx_index = 0;
        }

        HAL_UART_Receive_IT(&huart2, &usart2_rx_byte, 1);
    }

    /* ================= USART3 ================= */
    else if (huart->Instance == USART3)
    {
        uint8_t rx = usart3_rx_byte;

        if (usart3_rx_index < RX_BUFFER_SIZE - 1)
        {
            usart3_rx_buffer[usart3_rx_index++] = rx;
            usart3_rx_buffer[usart3_rx_index] = '\0';
        }

        if (strcmp(usart3_rx_buffer, "sagar") == 0)
        {
            char ok[] = "User know\r\n";
            HAL_UART_Transmit(&huart3, (uint8_t*)ok, sizeof(ok) - 1, HAL_MAX_DELAY);
            usart3_rx_index = 0;
        }
        else if (usart3_rx_index >= strlen("sagar"))
        {
            char nok[] = "Un know\r\n";
            HAL_UART_Transmit(&huart3, (uint8_t*)nok, sizeof(nok) - 1, HAL_MAX_DELAY);
            usart3_rx_index = 0;
        }

        HAL_UART_Receive_IT(&huart3, &usart3_rx_byte, 1);
    }
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    if (GPIO_Pin == GPIO_PIN_13)
    {
    	if (B1_Button_Flag == 0)
            B1_Button_Flag = 1;   // Button pressed
    }
}


void app1mstask (void){
	HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5); // Toggle LD2

	HAL_UART_Transmit(&huart2, (uint8_t*)msg, sizeof(msg)-1, HAL_MAX_DELAY);
	HAL_UART_Transmit(&huart3, (uint8_t*)msg1, sizeof(msg1)-1, HAL_MAX_DELAY);


	if (B1_Button_Flag)
	{
		B1_Button_Flag = 0;

		char msg[] = "B1 Button Pressed\r\n";
		HAL_UART_Transmit(&huart2, (uint8_t*)msg, sizeof(msg) - 1, HAL_MAX_DELAY);


	}

}

void serialsendapp (uint8_t rx){


}
