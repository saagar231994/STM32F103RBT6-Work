#include "main.h"
#include "string.h"

#define RX_BUFFER_SIZE  20


extern uint8_t usart2_rx_byte;
extern char    usart2_rx_buffer[RX_BUFFER_SIZE];
extern uint8_t usart2_rx_index;

/* USART3 RX context */
extern uint8_t usart3_rx_byte;
extern char    usart3_rx_buffer[RX_BUFFER_SIZE];
extern uint8_t usart3_rx_index;

extern const char msg[];
extern const char msg1[];
extern uint8_t ch;
extern volatile uint8_t B1_Button_Flag;

extern uint8_t  rx_byte;                        // single byte buffer
extern char     rx_buffer[RX_BUFFER_SIZE];      // command buffer
extern uint8_t  rx_index;

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim);
void app1mstask (void);
void serialsendapp (uint8_t rx);
