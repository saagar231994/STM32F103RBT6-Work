#include"app.h"
#include"main.h"

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  if (htim->Instance == TIM2)
  {
	  app1mstask();
  }
}


void app1mstask (void){
	HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5); // Toggle LD2

}
