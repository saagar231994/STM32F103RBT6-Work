#include"app.h"
#include"main.h"

uint8_t USART2_RxByte;
uint8_t ch = 'A';
const char msg[] = "Hello from STM32 USART2\r\n";



uint8_t  rx_byte;                        // single byte buffer
char     rx_buffer[RX_BUFFER_SIZE];      // command buffer
uint8_t  rx_index = 0;

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  if (htim->Instance == TIM2)
  {
	  app1mstask();
  }
}


void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART2)
    {
        rx_byte = USART2_RxByte;

        /* Store character */
        if (rx_index < RX_BUFFER_SIZE - 1)
        {
            rx_buffer[rx_index++] = rx_byte;
            rx_buffer[rx_index] = '\0';
        }

        /* VALID command */
        if (strcmp(rx_buffer, "sagar") == 0)
        {
            char ok[] = "User know\r\n";
            HAL_UART_Transmit(&huart2, (uint8_t*)ok, sizeof(ok) - 1, HAL_MAX_DELAY);
            rx_index = 0;   // reset buffer
        }
        /* INVALID command (longer than valid keyword) */
        else if (rx_index >= strlen("sagar"))
        {
            char nok[] = "Un know\r\n";
            HAL_UART_Transmit(&huart2, (uint8_t*)nok, sizeof(nok) - 1, HAL_MAX_DELAY);
            rx_index = 0;   // reset buffer
        }

        /* Re-arm RX */
        HAL_UART_Receive_IT(&huart2, &USART2_RxByte, 1);
    }
}


void app1mstask (void){
	HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5); // Toggle LD2

	HAL_UART_Transmit(&huart2, (uint8_t*)msg, sizeof(msg)-1, HAL_MAX_DELAY);

	//HAL_UART_Transmit(&huart2, &ch, 1, HAL_MAX_DELAY);

}
