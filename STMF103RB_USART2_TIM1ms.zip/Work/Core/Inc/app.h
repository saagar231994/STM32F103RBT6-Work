#include "main.h"
#include "string.h"

#define RX_BUFFER_SIZE  20


extern uint8_t USART2_RxByte;
extern const char msg[];
extern uint8_t ch;

extern uint8_t  rx_byte;                        // single byte buffer
extern char     rx_buffer[RX_BUFFER_SIZE];      // command buffer
extern uint8_t  rx_index;

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim);
void app1mstask (void);
